# Assignment_02

## 1


```python
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator

file='./earthquakes-2023-11-05_11-39-06_+0800.tsv'
Year=1
Month=2
Day=3
Hour=4
Minute=5
Second=6
Location_Name=9
Magnitude=13
Deaths=15

class Eqs:
    data=[]

    def __init__(self):
        idx=0
        with open(file, encoding='utf-8') as file_obj:
            for line in file_obj:
                list = line.split('\t')

                if(idx>1):
                    self.data.append({})
                    if(list[Year]==''):
                        self.data[idx - 2]['Year']=None
                    else:
                        self.data[idx-2]['Year']=int(list[Year])
                    if (list[Month] == ''):
                        self.data[idx - 2]['Month'] = None
                    else:
                        self.data[idx - 2]['Month'] = int(list[Month])
                    if (list[Day] == ''):
                        self.data[idx - 2]['Day'] = None
                    else:
                        self.data[idx - 2]['Day'] = int(list[Day])
                    if (list[Hour] == ''):
                        self.data[idx - 2]['Hour'] = None
                    else:
                        self.data[idx - 2]['Hour'] = int(list[Hour])
                    if (list[Minute] == ''):
                        self.data[idx - 2]['Minute'] = None
                    else:
                        self.data[idx - 2]['Minute'] = int(list[Minute])
                    if (list[Second] == ''):
                        self.data[idx - 2]['Second'] = None
                    else:
                        self.data[idx - 2]['Second'] = float(list[Second])
                    if(list[Location_Name]==''):
                        self.data[idx - 2]['Location_Name']=None
                    else:
                        self.data[idx-2]['Location_Name'] = eval(list[Location_Name]).split(':')[0]
                    if(list[Magnitude]==''):
                        self.data[idx - 2]['Magnitude']=None
                    else:
                        self.data[idx - 2]['Magnitude']=float(list[Magnitude])
                    if(list[Deaths]==''):
                        self.data[idx - 2]['Deaths']=None
                    else:
                        self.data[idx - 2]['Deaths']=int(list[Deaths])
                idx += 1
    def Func_1(self):
        country={}
        for dt in self.data:
            if dt['Location_Name'] not in country:
                country[dt['Location_Name']]=0
            else:
                if(dt['Deaths']!=None):
                    country[dt['Location_Name']]+=dt['Deaths']
        st_country=sorted(country.items(),key=lambda x:x[1],reverse=True)
        for i in range(10):
            print(st_country[i])
    def Func_2(self):
        year={}
        for dt in self.data:
            if dt['Year'] not in year:
                year[dt['Year']]=0
            else:
                if(dt['Magnitude']!=None and dt['Magnitude']>6.0):
                    year[dt['Year']]+=1
        st_year=sorted(year.items(),key=lambda x:x[0])
        years=[]
        nums=[]
        for item in st_year:
            years.append(item[0])
            nums.append(item[1])
        plt.figure(figsize=(24, 8))
        plt.scatter(years, nums)
        plt.xticks(fontsize=5)
        plt.xticks(rotation=90)
        x_major_locator = MultipleLocator(50)
        y_major_locator = MultipleLocator(1)
        ax = plt.gca()
        ax.xaxis.set_major_locator(x_major_locator)
        ax.yaxis.set_major_locator(y_major_locator)
        plt.show()
    def CountEq_LargestEq(self,name):
        cnt=0
        max_idx=-1
        for idx in range(len(self.data)):
            if(self.data[idx]['Location_Name']==name):
                cnt+=1
                if(max_idx==-1 and self.data[idx]['Magnitude']!=None):
                    max_idx=idx
                else:
                    if(self.data[idx]['Magnitude']!=None and self.data[idx]['Magnitude']>self.data[max_idx]['Magnitude']):
                        max_idx=idx
        return (cnt,str(self.data[max_idx]['Year'])+' '+str(self.data[max_idx]['Month'])+' '+str(self.data[max_idx]['Day'])+' '+str(self.data[max_idx]['Hour'])+' '+str(self.data[max_idx]['Minute'])+' '+str(self.data[max_idx]['Second']))
        # print(name,cnt,end=" ")
        # if(max_idx!=-1):
        #     print(self.data[max_idx]['Year'],self.data[max_idx]['Month'],self.data[max_idx]['Day'],self.data[max_idx]['Hour'],self.data[max_idx]['Minute'],self.data[max_idx]['Second'])
    def Func_3(self):
        country = {}
        for dt in self.data:
            if dt['Location_Name'] not in country:
                country[dt['Location_Name']] = list(self.CountEq_LargestEq(dt['Location_Name']))
        st_country = sorted(country.items(), key=lambda x: x[1][0], reverse=True)
        for item in st_country:
            print(item[0],end=' ')
            print(item[1][0],item[1][1])
```

## 1.1


```python
Sig_Eqs=Eqs()
Sig_Eqs.Func_1()
```

    ('CHINA', 2075045)
    ('TURKEY', 1092048)
    ('IRAN', 995406)
    ('ITALY', 498478)
    ('SYRIA', 369224)
    ('HAITI', 323478)
    ('AZERBAIJAN', 317219)
    ('JAPAN', 278085)
    ('ARMENIA', 191890)
    ('ISRAEL', 160120)


## 1.2


```python
Sig_Eqs.Func_2()
```


    
![png](output_5_0.png)
    


## 1.3


```python
Sig_Eqs.CountEq_LargestEq('CHINA')
Sig_Eqs.Func_3()
```

    CHINA 620 1668 7 25 None None None
    INDONESIA 394 2004 12 26 0 58 53.4
    IRAN 384 856 12 22 None None None
    JAPAN 354 2011 3 11 5 46 24.1
    ITALY 330 1915 1 13 6 52 38.0
    TURKEY 320 1939 12 26 23 57 23.8
    GREECE 257 365 7 21 None None None
    PHILIPPINES 220 1897 9 21 5 12 None
    MEXICO 199 1899 1 24 23 43 0.0
    CHILE 197 1960 5 22 19 11 17.0
    PERU 181 1716 2 6 None None None
    RUSSIA 151 1952 11 4 16 58 27.9
    BALKANS NW 118 1667 4 6 7 10 None
    PAPUA NEW GUINEA 103 1919 5 6 19 41 13.0
    CALIFORNIA 103 1857 1 9 10 13 0.0
    INDIA 98 1897 6 12 11 6 None
    TAIWAN 97 1920 6 5 4 21 35.0
    ALASKA 79 1964 3 28 3 36 0.0
    COLOMBIA 73 1826 6 18 3 40 0.0
    VENEZUELA 67 1894 4 29 2 45 0.0
    ECUADOR 66 1906 1 31 15 36 10.0
    NEW ZEALAND 63 1826 None None None None None
    SOLOMON ISLANDS 61 1977 4 21 4 24 9.6
    AFGHANISTAN 59 1909 7 7 21 37 50.0
    ALGERIA 57 1980 10 10 12 25 26.0
    ALBANIA 56 1893 6 14 None None None
    PAKISTAN 52 1945 11 27 21 56 50.0
    VANUATU ISLANDS 50 1913 10 14 8 8 48.0
    FRANCE 44 1817 3 11 20 10 0.0
    GUATEMALA 39 1942 8 6 23 36 59.0
    NICARAGUA 39 1898 4 29 16 18 None
    SPAIN 33 1954 3 29 6 17 0.0
    EL SALVADOR 33 1915 9 7 1 20 48.0
    SWITZERLAND 31 1601 9 18 None None None
    SYRIA 29 1202 5 20 None None None
    PORTUGAL 27 -60 None None None None None
    AZORES 27 1968 2 28 None None 0.0
    COSTA RICA 27 1822 5 7 None None None
    MYANMAR (BURMA) 26 1912 5 23 2 24 6.0
    NEW CALEDONIA 25 1875 3 28 None None None
    ISRAEL 24 -31 9 2 None None 0.0
    TAJIKISTAN 24 1907 10 21 4 23 36.0
    AUSTRALIA 23 2004 12 23 14 59 4.4
    KERMADEC ISLANDS 23 1986 10 20 6 46 9.9
    IRAQ 22 1864 12 2 None None None
    MOROCCO 21 2023 9 8 22 11 1.0
    ARGENTINA 21 1944 1 15 23 49 0.0
    HAITI 20 1842 5 7 21 None None
    SOUTH KOREA 19 1700 9 12 None None None
    JAMAICA 19 1899 6 14 11 9 None
    DOMINICAN REPUBLIC 18 1946 8 4 17 51 5.0
    TONGA ISLANDS 18 1919 4 30 7 17 17.3
    FIJI ISLANDS 18 1919 1 1 2 59 57.0
    BULGARIA 17 1904 4 4 10 27 None
    ICELAND 17 1912 5 6 18 59 0.0
    PANAMA 16 1882 9 7 7 50 0.0
    BANGLADESH 16 1918 7 8 10 22 7.0
    KYRGYZSTAN 15 1946 11 2 18 28 0.0
    EGYPT 15 1995 11 22 4 15 11.9
    GEORGIA 15 1905 10 21 11 1 37.0
    AZERBAIJAN 15 1667 11 None None None None
    CANADA 15 1949 8 22 4 1 12.2
    UNITED KINGDOM 14 1580 4 6 None None None
    UZBEKISTAN 14 1976 4 8 2 40 27.0
    ROMANIA 14 1977 3 4 19 21 55.6
    CUBA 14 2020 1 28 19 10 25.0
    PUERTO RICO 14 1943 7 29 3 2 0.0
    SANRIKU, JAPAN 13 1257 10 9 None None None
    ETHIOPIA 13 1906 8 25 13 47 37.2
    SOUTH AFRICA 13 1942 11 10 11 41 27.0
    LEBANON 12 551 7 9 None None None
    UKRAINE 12 103 None None None None None
    GUAM 12 1902 9 22 1 46 30.0
    TURKMENISTAN 11 1895 7 8 21 30 None
    ARMENIA 11 1988 12 7 7 41 24.2
    NEPAL 11 2015 4 25 6 11 26.0
    HAWAII 11 1868 4 3 2 24 None
    HONDURAS 11 1856 8 4 None None None
    KAZAKHSTAN 10 1889 7 11 22 14 0.0
    YEMEN 10 1982 12 13 9 12 48.0
    TUNISIA 9 1957 2 20 4 41 1.0
    GREECE-ALBANIA 9 1911 2 18 21 36 None
    GERMANY 9 1978 9 3 5 8 30.2
    MARTINIQUE 9 1906 12 3 22 59 0.0
    GUADELOUPE 8 1843 2 8 14 50 0.0
    UTAH 8 1934 3 12 15 5 40.0
    TANZANIA 8 1910 12 13 11 37 28.2
    BRAZIL 8 1963 11 9 21 15 32.3
    CYPRUS 7 1953 9 10 4 6 4.1
    AUSTRIA 7 1590 9 15 None None None
    CONGO 7 1992 9 11 3 57 26.5
    COSTA RICA-PANAMA 7 1941 12 5 20 46 58.0
    MONGOLIA 7 1905 7 9 9 40 24.0
    NEVADA 7 1915 10 3 6 52 48.0
    SOUTH SANDWICH ISLANDS 7 1929 6 27 12 47 13.9
    POLAND 7 2004 9 21 13 32 30.8
    OKLAHOMA 7 2011 11 6 3 53 10.0
    NORTH KOREA 6 1518 7 2 None None None
    TOKAIDO, JAPAN 6 1782 8 22 None None None
    ALASKA PENINSULA 6 2021 7 29 6 15 47.0
    NEW YORK 6 1944 9 5 4 38 45.7
    SAMOA ISLANDS 6 1917 6 26 5 49 42.0
    MONTANA 6 1959 8 18 6 37 13.5
    JORDAN 5 -2150 None None None None None
    NEPAL-INDIA 5 1505 6 6 None None None
    GHANA 5 1862 7 10 8 15 0.0
    S. MEXICO 5 1925 11 16 11 54 54.0
    HUNGARY 5 1834 10 15 6 30 0.0
    TRINIDAD 5 2006 9 29 13 8 26.1
    SW. SUMATRA 5 1797 2 10 None None None
    VIRGIN ISLANDS 5 1867 11 18 18 45 None
    TONGA TRENCH 5 1982 12 19 17 43 54.8
    WASHINGTON 5 1949 4 13 19 55 42.0
    MICRONESIA, FED. STATES OF 5 1911 8 16 22 41 18.0
    VIETNAM 5 1935 11 1 16 22 9.0
    PANAMA-COSTA RICA 5 1934 7 18 1 36 24.0
    RWANDA 5 2015 8 7 1 25 2.5
    BHUTAN 5 2009 9 21 8 53 5.9
    THAILAND 4 2014 5 5 11 8 43.4
    TURKEY; ARMENIA 4 1679 6 4 None None 0.0
    SEIKAIDO, JAPAN 4 1970 7 25 22 41 10.7
    TURKEY; SYRIA 4 2023 2 6 1 17 35.0
    HAWAIIAN ISLANDS 4 1871 2 20 8 41 None
    VANUATU 4 1878 1 10 None None None
    COLOMBIA-ECUADOR 4 1958 1 19 14 7 27.0
    UGANDA 4 1912 7 9 None None None
    INDIAN OCEAN 4 1928 3 9 18 5 27.0
    ATLANTIC OCEAN 4 1941 11 25 18 3 57.5
    PERU-ECUADOR 4 1953 12 12 17 31 25.0
    MALAWI 4 1989 3 10 21 49 45.8
    SLOVAKIA 3 2004 1 10 7 43 18.0
    MISSOURI 3 1812 2 7 9 45 0.0
    PENNSYLVANIA 3 1840 11 11 None None None
    SE. HOKKAIDO ISLAND, JAPAN 3 1839 5 1 None None None
    SOUTH SUDAN 3 1990 5 20 2 22 1.6
    S. JAVA SEA 3 1930 7 19 15 20 12.0
    KASHIMA, JAPAN 3 1927 8 18 19 28 None
    BOLIVIA 3 1957 11 29 22 19 0.0
    MALAYSIA 3 1976 7 26 2 56 39.3
    NORTHERN MARIANA ISLANDS 3 2016 7 29 21 18 24.7
    THE NETHERLANDS 3 1992 4 13 1 20 0.8
    TAIWAN REGION 3 1996 9 5 23 42 6.0
    SCOTIA SEA 3 2013 11 17 9 4 55.5
    SAUDI ARABIA 3 2009 5 19 17 35 0.6
    AFGHANISTAN; PAKISTAN 3 2015 12 25 19 14 47.2
    SYRIAN COASTS 2 2023 10 15 3 36 0.0
    IRAN-IRAQ 2 1008 4 11 None None None
    MARMARA SEA 2 2023 10 15 3 36 0.0
    SEIONAIKAI, JAPAN 2 1510 9 21 None None None
    BOSO, JAPAN 2 1642 9 4 None None None
    PERU-CHILE 2 1833 9 18 10 45 None
    W. LUZON ISLAND, PHILIPPINES 2 1925 5 5 10 6 6.0
    GREECE-BULGARIA 2 2023 10 15 3 36 0.0
    LEBANON-SYRIA 2 2008 2 15 10 36 19.0
    SAINT LUCIA 2 2023 10 15 3 36 0.0
    TOGO 2 1788 None None None None 0.0
    CANARY ISLANDS 2 2023 10 15 3 36 0.0
    ARKANSAS 2 1811 12 16 8 15 None
    W. HOKKAIDO ISLAND, JAPAN 2 1947 11 4 0 9 10.0
    FLORES SEA 2 1836 11 28 None None None
    N. NEW ZEALAND 2 1950 3 14 18 10 41.0
    N. MEXICO 2 1852 11 29 None None None
    VIRGIN ISLANDS; PUERTO RICO 2 2023 10 15 3 36 0.0
    COTE D'IVOIRE 2 1879 2 11 6 None 0.0
    ERITREA 2 1884 7 20 9 30 None
    W. SOLOMON SEA 2 1895 3 6 8 35 None
    IWATE, JAPAN 2 1979 2 20 6 32 32.2
    EL SALVADOR-GUATEMALA 2 1902 2 26 None None None
    PANAMA-COLOMBIA 2 1904 1 20 14 52 6.0
    CAMEROON 2 1945 9 12 0 51 0.0
    BOLIVIA-NORTHERN CHILE 2 1916 8 25 9 44 42.0
    KENYA 2 1928 1 6 19 31 58.5
    BRITISH COLUMBIA 2 1946 6 23 17 13 19.0
    MYANMAR; INDIA 2 1954 3 21 23 42 11.0
    JAPAN TRENCH 2 1971 8 2 7 24 56.8
    INDIA-CHINA 2 1950 8 15 14 9 30.0
    CHILE-ARGENTINA 2 1950 12 9 21 38 48.0
    IDAHO 2 1983 10 28 14 6 6.5
    KENTUCKY 2 1980 7 27 18 52 21.8
    SAMOA 2 1981 9 1 9 29 31.5
    WYOMING 2 1994 2 3 9 5 4.2
    MYANMAR (BURMA);  INDIA 2 1988 8 6 0 36 24.6
    INDIA-BANGLADESH 2 1997 11 21 11 23 6.3
    AFGHANISTAN-TAJIKISTAN 2 1998 2 20 12 18 6.2
    MOZAMBIQUE 2 2006 2 22 22 19 7.8
    COLORADO 2 2011 8 23 5 46 18.2
    PERU-BRAZIL 2 2015 11 24 22 45 38.9
    EAST MEDITERRANEAN SEA 1 2023 10 15 3 36 0.0
    GREECE-TURKEY 1 2023 10 15 3 36 0.0
    INSTANBUL (CONSTANTINOPLE) 1 2023 10 15 3 36 0.0
    SYRIA;  ISRAEL; ASIA 1 2023 10 15 3 36 0.0
    AFGHANISTAN; INDIA 1 818 5 15 None None None
    SPAIN; ALGERIA; MOROCCO 1 881 5 26 None None None
    IRAQ-SYRIA 1 2023 10 15 3 36 0.0
    SAGAMI, JAPAN 1 1331 8 15 None None None
    SOUTH COASTS OF ASIA MINOR 1 2023 10 15 3 36 0.0
    IRELAND 1 2023 10 15 3 36 0.0
    CANO ISLAND 1 2023 10 15 3 36 0.0
    SURUGA, JAPAN 1 1589 3 21 None None None
    PUERTO RICO;  DOMINICAN REPUBLIC 1 2023 10 15 3 36 0.0
    YATSUSHIRO, JAPAN 1 1619 5 1 None None None
    SEA OF JAPAN 1 1643 7 25 None None None
    YELLOW SEA 1 1649 12 9 None None None
    MIYAKOJIMA, JAPAN 1 1667 None None None None None
    BOSTON AND SALEM, MASSACHUSETTS 1 2023 10 15 3 36 0.0
    E. SPORADES ISLANDS, AEGEAN ISLANDS 1 2023 10 15 3 36 0.0
    ANTIGUA; SAINT KITTS AND NEVIS 1 1690 4 16 None None None
    SEIKAIDO-NANKAIDO 1 1698 12 22 None None None
    CASCADIA SUBDUCTION ZONE 1 1700 1 27 5 0 None
    MYNAMAR (BURMA) 1 2023 10 15 3 36 0.0
    KOORI 1 1731 10 7 None None None
    E. LUZON ISLAND, PHILIPPINES 1 2023 10 15 3 36 0.0
    MYANMAR (BURMA) COAST 1 2023 10 15 3 36 0.0
    MASSACHUSETTS 1 1755 11 18 9 11 35.0
    RUSSIA; MONGOLIA 1 1761 12 9 17 20 0.0
    N. SANRIKU, JAPAN 1 1763 3 11 None None None
    MARTINIQUE & BARBADOS 1 2023 10 15 3 36 0.0
    SW. KYUSHU ISLAND, JAPAN 1 1769 8 29 None None None
    FRENCH GUIANA 1 2023 10 15 3 36 0.0
    SIERRA LEONE 1 1795 5 20 22 None None
    ANTIGUA ISLAND &  ST. CHRISTOPHER 1 2023 10 15 3 36 0.0
    E. AWA, TOKUSHIMA PREFECTURE 1 1808 8 8 None None None
    INDONESIA; MALAYSIA 1 2023 10 15 3 36 0.0
    NORWAY 1 1819 8 31 None None None
    ROMANIA; MOLDOVA 1 1821 11 17 13 30 None
    GRENADA 1 2023 10 15 3 36 0.0
    LAKE ERIE (GREAT LAKES) 1 2023 10 15 3 36 0.0
    GUAM; NORTHERN MARIANA ISLANDS 1 2023 10 15 3 36 0.0
    BARBADOS, SAINT VINCENT, DOMINICA, ANTIGUA 1 2023 10 15 3 36 0.0
    TRINIDAD & ST. CHRISTOPHER 1 1831 12 3 23 40 0.0
    SAINT VINCENT 1 2023 10 15 3 36 0.0
    FRENCH POLYNESIA 1 1848 7 12 None None None
    ENSHUNADA 1 1855 11 7 None None None
    SHINANO 1 2023 10 15 3 36 0.0
    EL SALVADOR; GUATEMALA; NICARAGUA 1 1859 12 9 2 0 None
    NW. HOKKAIDO ISLAND, JAPAN 1 1863 9 20 None None None
    OFF COAST SW AVALON PENINSULA, NEWFOUNDLAND 1 2023 10 15 3 36 0.0
    None 1 1868 10 18 12 35 None
    BRITISH VIRGIN ISLANDS 1 2023 10 15 3 36 0.0
    NEW HAMPSHIRE 1 2023 10 15 3 36 0.0
    GISBORNE 1 1880 9 8 None None None
    TOYAMA PREF., JAPAN 1 2023 10 15 3 36 0.0
    ARMENIA; AZERBAIJAN 1 2023 10 15 3 36 0.0
    SRI LANKA 1 2023 10 15 3 36 0.0
    FIJI 1 2023 10 15 3 36 0.0
    CONNECTICUT 1 2023 10 15 3 36 0.0
    BRAZIL; FRENCH GUIANA; SURINAME; GUYANA 1 1885 8 4 9 43 None
    SOUTH CAROLINA 1 1886 9 1 2 51 0.0
    TRINIDAD; GRENADA 1 1888 1 10 12 55 None
    URUGUAY 1 2023 10 15 3 36 0.0
    TIMOR SEA 1 1891 10 5 None None None
    BALKANS 1 2023 10 15 3 36 0.0
    NEMURO, JAPAN 1 2023 10 15 3 36 0.0
    W. KYUSHU ISLAND, JAPAN 1 2023 10 15 3 36 0.0
    NEW JERSEY 1 1895 9 1 11 9 None
    MONTSERRAT 1 2023 10 15 3 36 0.0
    GUADELOUPE; ANTIGUA; ST KITTS 1 2023 10 15 3 36 0.0
    KIRIBATI 1 1905 6 30 17 7 0.0
    TASMAN SEA 1 1913 2 22 2 36 None
    EL SALVADOR; HONDURAS 1 1915 12 29 None None None
    NEPAL; TIBET (XIZANG PROVINCE) 1 1916 8 28 6 39 29.0
    CENTRAL AFRICAN REPUBLIC 1 1921 9 16 0 51 0.0
    LHOKNGA, ACEH 1 2023 10 15 3 36 0.0
    SE. NEW ZEALAND 1 1922 12 25 3 33 10.0
    NORTH ATLANTIC RIDGE 1 1925 10 13 17 40 0.0
    CALIFORNIA, MEXICO 1 1927 1 1 8 16 0.0
    ISRAEL; JORDAN 1 1927 7 11 13 4 None
    JAVA-S. JAVA SEA 1 1930 6 19 13 7 27.0
    UK 1 1931 6 7 0 25 21.0
    PACIFIC OCEAN 1 1932 11 2 None None 0.0
    NEPAL; INDIA 1 1934 1 15 8 43 25.0
    SOLOMON ISLANDS; NEW CALEDONIA 1 1934 7 21 6 18 23.3
    E. HOKKAIDO ISLAND, JAPAN 1 1938 5 28 16 42 None
    TURKEY-CIS 1 1940 5 7 22 23 0.0
    CALIFORNIA; MEXICO 1 1940 5 19 4 36 40.9
    COSTA RICA-NICARAGUA 1 1950 10 5 16 9 31.0
    PERU-BOLIVIA 1 1952 2 26 11 31 0.0
    NE. HOKKAIDO ISLAND, JAPAN 1 2023 10 15 3 36 0.0
    EAST PACIFIC RIDGE 1 1958 11 4 22 54 46.0
    LIBYA 1 1963 2 21 17 14 31.0
    NW. HONSHU ISLAND, JAPAN 1 2023 10 15 3 36 0.0
    NORTH CORINTH GULF 1 1965 7 6 3 18 45.1
    INDONESIA-MALAYSIA 1 1967 4 12 4 51 50.2
    MEXICO-GUATEMALA 1 1968 9 25 10 38 39.5
    PORTUGAL; MOROCCO 1 1969 2 28 2 40 32.5
    COLOMBIA; SAN CRISTOBAL, VENEZUELA 1 1973 4 24 21 30 9.9
    ANTARCTICA 1 1973 10 6 15 7 37.3
    GABON 1 1974 9 23 19 28 17.2
    ANTIGUA AND BARBUDA; ST KITTS 1 1974 10 8 9 50 58.1
    ITALY-BALKANS NW 1 1976 9 15 9 21 19.1
    AFGHANISTAN; TAJIKISTAN 1 1976 11 27 21 42 12.2
    MINDANAO ISLAND, PHILIPPINES 1 1978 6 14 12 32 33.9
    MONTENEGRO 1 1979 4 9 2 10 20.3
    HONDURAS;  N GUATEMALA 1 1980 8 9 5 45 9.5
    VENEZUELA-N COLOMBIA 1 1981 10 18 4 31 2.7
    CANADA; MAINE 1 1982 1 11 21 41 7.9
    IBARAKI, JAPAN 1 1982 7 23 14 23 53.5
    HONDURAS-GUATEMALA-EL SALVADOR 1 1982 9 29 5 50 32.2
    NOSHIRO, JAPAN 1 1983 6 9 12 49 3.8
    BELGIUM 1 1983 11 8 0 49 32.1
    GUINEA 1 1983 12 22 4 11 29.2
    PAKISTAN-NW AFGHANISTAN 1 1984 2 16 17 18 41.6
    BOSNIA-HERZEGOVINA 1 1984 5 13 12 45 55.8
    CALIFORNIA-NEVADA 1 1986 7 21 14 42 26.6
    MACQUARIE ISLAND 1 1989 5 23 10 54 46.3
    DJIBOUTI 1 1989 8 20 11 16 56.5
    BERING SEA 1 1991 2 21 2 35 34.0
    NEVADA-CALIFORNIA BORDER 1 1992 6 29 10 14 22.2
    FUTUNA ISLAND 1 1993 3 12 14 1 35.4
    WASHINGTON-OREGON BORDER 1 1993 3 25 13 34 35.4
    SUDAN 1 1993 8 1 0 20 40.5
    OREGON 1 1993 9 21 3 28 55.4
    BOLIVIA-PERU 1 1994 6 9 0 33 16.2
    HONSHU ISLAND, JAPAN 1 1996 9 4 18 16 1.9
    TOBAGO 1 1997 4 22 9 31 23.2
    BALLENY ISLANDS 1 1998 3 25 3 12 25.0
    ARMENIA-AZERBAIJAN-IRAN 1 1998 7 9 14 19 18.4
    INDIA-BANGLADESH BORDER 1 2000 1 3 22 34 12.6
    SOUTH AFRICA; SWAZILAND 1 2000 2 7 19 34 57.0
    EL SALVADOR; GUATEMALA 1 2001 1 13 17 33 32.3
    LAOS;  VIETNAM 1 2001 2 19 15 51 35.0
    TAJIKISTAN; AFGHANISTAN 1 2002 4 12 4 0 23.7
    ALABAMA 1 2003 4 29 8 59 39.0
    BURUNDI 1 2004 2 24 2 14 34.0
    SLOVENIA 1 2004 7 12 13 4 7.1
    GREECE-BULGARIA BORDER REGION 1 2006 2 20 17 20 9.0
    GULF OF MEXICO 1 2006 9 10 14 56 8.1
    LAOS 1 2007 5 16 8 56 16.4
    ILLINOIS 1 2008 4 18 9 36 59.1
    CZECH REPUBLIC 1 2008 11 22 22 27 55.1
    PAKISTAN; INDIA 1 2009 2 20 3 48 48.2
    ANATAHAN REGION, N. MARIANA ISLANDS 1 2010 5 29 11 46 50.3
    GUAM, NORTHERN MARIANA ISLANDS 1 2010 8 13 21 19 33.0
    MYANMAR 1 2011 3 24 13 55 12.0
    VIRGINIA 1 2011 8 23 17 51 4.5
    IRAN; PAKISTAN 1 2013 4 16 10 44 20.1
    TEXAS 1 2013 4 18 0 50 38.5
    GREECE, TURKEY 1 2014 5 24 9 25 2.4
    MEXICO; GUATEMALA 1 2014 7 7 11 23 54.8
    COLOMBIA-PANAMA 1 2015 7 29 0 10 24.7
    MADAGASCAR 1 2017 1 11 22 7 7.0
    ZAMBIA 1 2017 2 24 0 32 8.0
    COMOROS 1 2018 5 15 15 49 34.0
    MOZAMBIQUE; ZIMBABWE 1 2018 12 22 5 38 27.0
    NORTH CAROLINA 1 2020 8 9 12 7 37.0
    TONGA 1 2023 5 10 16 2 0.0


## 2

DATE字段标识日期，以-分隔前两字段为年，月，WND字段标识风数据，第四字段表示风速。


```python
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
import pandas as pd

file='./2281305.csv'

class Windspeed:
    result={}
    def __init__(self):
        data = pd.read_csv(file, sep=',',low_memory=False)

        for index,row in data.iterrows():
            lst=row['DATE'].split('-')
            date=lst[0]+'-'+lst[1]
            para=row['WND'].split(',')
            speed=int(para[3])
            if date not in self.result:
                self.result[date]=[speed,1]
            else:
                if(speed!=9999):
                    self.result[date][0]+=speed
                self.result[date][1]+=1
        self.result=sorted(self.result.items(),key=lambda x:x[0])
    def Draw(self):
        x=[]
        y=[]
        for item in self.result:
            x.append(item[0])
            y.append(item[1][0]/item[1][1])
        # plt.scatter(x, y)
        plt.figure(figsize=(24, 8))
        plt.xticks(fontsize=5)
        plt.xticks(rotation=90)
        plt.bar(x,y)

        plt.show()

    ws=Windspeed()
    ws.Draw()
```


    
![png](output_9_0.png)
    


## 3

## 3.1

对2023年河北气象观测数据操作。

## 3.2


```python
import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
import pandas as pd

file='./57494099999.csv'

class TEMP:
    result={}
    max_on_hour=-9999
    min_on_hour=9999
    max_on_hour_date=''
    min_on_hour_date = ''
    cnt_above250_on_hour=0
    cnt_below50_on_hour = 0
    diff_on_month=[]
    def __init__(self):
        data = pd.read_csv(file, sep=',',low_memory=False)
        for i in range(11):
            self.diff_on_month.append([-9999,9999])
        for index,row in data.iterrows():
            lst=row['DATE'].split('-')
            date=lst[0]+'-'+lst[1]
            para=row['TMP'].split(',')
            temp=int(para[0])
            if date not in self.result:
                self.result[date]=[temp,1]
            else:
                if(temp!=9999):
                    if(temp>250):
                        self.cnt_above250_on_hour+=1
                    elif(temp<50):
                        self.cnt_below50_on_hour+=1
                    if(temp>self.max_on_hour):
                        self.max_on_hour=temp
                        self.max_on_hour_date=row['DATE']
                    if(temp<self.min_on_hour):
                        self.min_on_hour=temp
                        self.min_on_hour_date=row['DATE']
                    if(temp<self.diff_on_month[int(lst[1])-1][1]):
                        self.diff_on_month[int(lst[1])-1][1]=temp
                    if (temp > self.diff_on_month[int(lst[1])-1][0]):
                        self.diff_on_month[int(lst[1])-1][0] = temp
                    self.result[date][0]+=temp
                self.result[date][1]+=1
        self.result=sorted(self.result.items(),key=lambda x:x[0])
    def Draw(self):
        x=[]
        y=[]
        for item in self.result:
            x.append(item[0])
            y.append(item[1][0]/item[1][1])
        # plt.scatter(x, y)
        plt.figure(figsize=(24, 8))
        plt.xticks(fontsize=5)
        plt.xticks(rotation=90)
        plt.bar(x,y)

        plt.show()
    def diff_per_month(self):
        for i in range(11):
            print("%d月：最低%d 最高%d" % (i+1,self.diff_on_month[i][1],self.diff_on_month[i][0]))
    def get_max(self):
        print("max:%d date:" % self.max_on_hour,self.max_on_hour_date)
    def get_min(self):
        print("min:%d date:" % self.min_on_hour,self.min_on_hour_date)
    def above(self):
        print("total %d hour above 250" % self.cnt_above250_on_hour)
    def below(self):
        print("total %d hour below 50" % self.cnt_below50_on_hour)
```


```python
tp=TEMP()
tp.Draw()
```


    
![png](output_12_0.png)
    


## 3.3


```python
tp.above()
tp.below()
tp.get_max()
tp.get_min()
tp.diff_per_month()
```

    total 3271 hour above 250
    total 524 hour below 50
    max:390 date: 2023-08-05T08:00:00
    min:-56 date: 2023-01-27T21:00:00
    1月：最低-56 最高210
    2月：最低-20 最高180
    3月：最低27 最高260
    4月：最低76 最高340
    5月：最低128 最高343
    6月：最低190 最高360
    7月：最低230 最高380
    8月：最低192 最高390
    9月：最低190 最高360
    10月：最低95 最高300
    11月：最低138 最高291



```python

```
