import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator

file='./earthquakes-2023-11-05_11-39-06_+0800.tsv'
Year=1
Month=2
Day=3
Hour=4
Minute=5
Second=6
Location_Name=9
Magnitude=13
Deaths=15

class Eqs:
    data=[]

    def __init__(self):
        idx=0
        with open(file, encoding='utf-8') as file_obj:
            for line in file_obj:
                list = line.split('\t')

                if(idx>1):
                    self.data.append({})
                    if(list[Year]==''):
                        self.data[idx - 2]['Year']=None
                    else:
                        self.data[idx-2]['Year']=int(list[Year])
                    if (list[Month] == ''):
                        self.data[idx - 2]['Month'] = None
                    else:
                        self.data[idx - 2]['Month'] = int(list[Month])
                    if (list[Day] == ''):
                        self.data[idx - 2]['Day'] = None
                    else:
                        self.data[idx - 2]['Day'] = int(list[Day])
                    if (list[Hour] == ''):
                        self.data[idx - 2]['Hour'] = None
                    else:
                        self.data[idx - 2]['Hour'] = int(list[Hour])
                    if (list[Minute] == ''):
                        self.data[idx - 2]['Minute'] = None
                    else:
                        self.data[idx - 2]['Minute'] = int(list[Minute])
                    if (list[Second] == ''):
                        self.data[idx - 2]['Second'] = None
                    else:
                        self.data[idx - 2]['Second'] = float(list[Second])
                    if(list[Location_Name]==''):
                        self.data[idx - 2]['Location_Name']=None
                    else:
                        self.data[idx-2]['Location_Name'] = eval(list[Location_Name]).split(':')[0]
                    if(list[Magnitude]==''):
                        self.data[idx - 2]['Magnitude']=None
                    else:
                        self.data[idx - 2]['Magnitude']=float(list[Magnitude])
                    if(list[Deaths]==''):
                        self.data[idx - 2]['Deaths']=None
                    else:
                        self.data[idx - 2]['Deaths']=int(list[Deaths])
                idx += 1
    def Func_1(self):
        country={}
        for dt in self.data:
            if dt['Location_Name'] not in country:
                country[dt['Location_Name']]=0
            else:
                if(dt['Deaths']!=None):
                    country[dt['Location_Name']]+=dt['Deaths']
        st_country=sorted(country.items(),key=lambda x:x[1],reverse=True)
        for i in range(10):
            print(st_country[i])
    def Func_2(self):
        year={}
        for dt in self.data:
            if dt['Year'] not in year:
                year[dt['Year']]=0
            else:
                if(dt['Magnitude']!=None and dt['Magnitude']>6.0):
                    year[dt['Year']]+=1
        st_year=sorted(year.items(),key=lambda x:x[0])
        years=[]
        nums=[]
        for item in st_year:
            years.append(item[0])
            nums.append(item[1])
        plt.figure(figsize=(24, 8))
        plt.scatter(years, nums)
        plt.xticks(fontsize=5)
        plt.xticks(rotation=90)
        x_major_locator = MultipleLocator(50)
        y_major_locator = MultipleLocator(1)
        ax = plt.gca()
        ax.xaxis.set_major_locator(x_major_locator)
        ax.yaxis.set_major_locator(y_major_locator)
        plt.show()
    def CountEq_LargestEq(self,name):
        cnt=0
        max_idx=-1
        for idx in range(len(self.data)):
            if(self.data[idx]['Location_Name']==name):
                cnt+=1
                if(max_idx==-1 and self.data[idx]['Magnitude']!=None):
                    max_idx=idx
                else:
                    if(self.data[idx]['Magnitude']!=None and self.data[idx]['Magnitude']>self.data[max_idx]['Magnitude']):
                        max_idx=idx
        return (cnt,str(self.data[max_idx]['Year'])+' '+str(self.data[max_idx]['Month'])+' '+str(self.data[max_idx]['Day'])+' '+str(self.data[max_idx]['Hour'])+' '+str(self.data[max_idx]['Minute'])+' '+str(self.data[max_idx]['Second']))
        # print(name,cnt,end=" ")
        # if(max_idx!=-1):
        #     print(self.data[max_idx]['Year'],self.data[max_idx]['Month'],self.data[max_idx]['Day'],self.data[max_idx]['Hour'],self.data[max_idx]['Minute'],self.data[max_idx]['Second'])
    def Func_3(self):
        country = {}
        for dt in self.data:
            if dt['Location_Name'] not in country:
                country[dt['Location_Name']] = list(self.CountEq_LargestEq(dt['Location_Name']))
        st_country = sorted(country.items(), key=lambda x: x[1][0], reverse=True)
        for item in st_country:
            print(item[0],end=' ')
            print(item[1][0],item[1][1])
    def print(self):
        print(self.data[-3])
        print(self.data[-2])
        print(self.data[-1])
        # idx=0
        # for d in self.data:
        #     idx+=1
        #     print(d)
        #     if(idx>10):
        #         break



if __name__ == '__main__':
    Sig_Eqs=Eqs()
    # Sig_Eqs.Func_1()
    Sig_Eqs.Func_2()
    # Sig_Eqs.CountEq_LargestEq('CHINA')
    # Sig_Eqs.Func_3()