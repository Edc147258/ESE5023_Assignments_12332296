import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
import pandas as pd

file='./2281305.csv'

class Windspeed:
    result={}
    def __init__(self):
        data = pd.read_csv(file, sep=',',low_memory=False)

        for index,row in data.iterrows():
            lst=row['DATE'].split('-')
            date=lst[0]+'-'+lst[1]
            para=row['WND'].split(',')
            speed=int(para[3])
            if date not in self.result:
                self.result[date]=[speed,1]
            else:
                if(speed!=9999):
                    self.result[date][0]+=speed
                self.result[date][1]+=1
        self.result=sorted(self.result.items(),key=lambda x:x[0])
    def Draw(self):
        x=[]
        y=[]
        for item in self.result:
            x.append(item[0])
            y.append(item[1][0]/item[1][1])
        # plt.scatter(x, y)
        plt.figure(figsize=(24, 8))
        plt.xticks(fontsize=5)
        plt.xticks(rotation=90)
        plt.bar(x,y)

        plt.show()
if __name__ == '__main__':
    ws=Windspeed()
    ws.Draw()