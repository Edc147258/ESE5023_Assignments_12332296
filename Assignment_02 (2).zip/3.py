import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
import pandas as pd

file='./57494099999.csv'

class TEMP:
    result={}
    max_on_hour=-9999
    min_on_hour=9999
    max_on_hour_date=''
    min_on_hour_date = ''
    cnt_above250_on_hour=0
    cnt_below50_on_hour = 0
    diff_on_month=[]
    def __init__(self):
        data = pd.read_csv(file, sep=',',low_memory=False)
        for i in range(11):
            self.diff_on_month.append([-9999,9999])
        for index,row in data.iterrows():
            lst=row['DATE'].split('-')
            date=lst[0]+'-'+lst[1]
            para=row['TMP'].split(',')
            temp=int(para[0])
            if date not in self.result:
                self.result[date]=[temp,1]
            else:
                if(temp!=9999):
                    if(temp>250):
                        self.cnt_above250_on_hour+=1
                    elif(temp<50):
                        self.cnt_below50_on_hour+=1
                    if(temp>self.max_on_hour):
                        self.max_on_hour=temp
                        self.max_on_hour_date=row['DATE']
                    if(temp<self.min_on_hour):
                        self.min_on_hour=temp
                        self.min_on_hour_date=row['DATE']
                    if(temp<self.diff_on_month[int(lst[1])-1][1]):
                        self.diff_on_month[int(lst[1])-1][1]=temp
                    if (temp > self.diff_on_month[int(lst[1])-1][0]):
                        self.diff_on_month[int(lst[1])-1][0] = temp
                    self.result[date][0]+=temp
                self.result[date][1]+=1
        self.result=sorted(self.result.items(),key=lambda x:x[0])
    def Draw(self):
        x=[]
        y=[]
        for item in self.result:
            x.append(item[0])
            y.append(item[1][0]/item[1][1])
        # plt.scatter(x, y)
        plt.figure(figsize=(24, 8))
        plt.xticks(fontsize=5)
        plt.xticks(rotation=90)
        plt.bar(x,y)

        plt.show()
    def diff_per_month(self):
        for i in range(11):
            print("%d月：最低%d 最高%d" % (i+1,self.diff_on_month[i][1],self.diff_on_month[i][0]))
    def get_max(self):
        print("max:%d date:" % self.max_on_hour,self.max_on_hour_date)
    def get_min(self):
        print("min:%d date:" % self.min_on_hour,self.min_on_hour_date)
    def above(self):
        print("total %d hour above 250" % self.cnt_above250_on_hour)
    def below(self):
        print("total %d hour below 50" % self.cnt_below50_on_hour)
if __name__ == '__main__':
    tp=TEMP()
    tp.Draw()
    tp.above()
    tp.below()
    tp.get_max()
    tp.get_min()
    tp.diff_per_month()